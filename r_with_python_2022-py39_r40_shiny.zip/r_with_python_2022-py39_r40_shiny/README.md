# conda_binder
Basic Conda based Binder

[![Binder](https://mybinder.org/badge_logo.svg)](https://mybinder.org/v2/gh/mafreitas/r_with_python_2022/py39_r40_shiny?urlpath=shiny)
